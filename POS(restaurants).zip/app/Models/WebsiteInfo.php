<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WebsiteInfo extends Model
{
    protected $fillable = [
        'name',
        'logo',
        'contact',
        'delivery',
        'multi_cart',
    ];
}
