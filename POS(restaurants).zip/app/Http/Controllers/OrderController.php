<?php

namespace App\Http\Controllers;

use App\Models\Tax;
use App\Models\Cart;
use App\Models\Promotion;
use App\Models\StoreItem;
use App\Models\WebsiteInfo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function order(Request $req){
        DB::beginTransaction();
        $multiCart=WebsiteInfo::where('id',1)->first()->multi_cart;
        if ($multiCart) {
            $cart=Cart::where('user_id',Auth::user()->id)->get();
        }else{
            $cart=json_decode($req->cartProduct);
        }
        $totalPrice=0;
        $profit=0;
        $promotionPrice=0;
        $taxPrice=0;
        foreach ($cart as $item) {
            $storeItem=StoreItem::find($item->store_item_id);
            $totalPrice+=$item->price*$item->qty;
            $profit+=$storeItem->profit*$item->qty;
            if (!$multiCart) {
                if ($storeItem->qty>=$item->qty) {
                    $storeItem->decrement($item->qty);
                    $storeItem->save();
                    logger('decrement');
                }
            }
        }
        $payleft=$req->subTotal-$req->payAmount;
        $change=$req->payAmount-$req->subTotal;
        $orderData=[
            'user_name'=>$req->userName,
            'user_email'=>$req->userEmail,
            'user_phone'=>$req->userPhone,
            'payment_method'=>$req->paymentMethod,
            'promotion_id'=>$req->promotionId,
            'promotion_price'=>$req->promotionPrice,
            'total_price'=>$totalPrice,
            'subtotal'=>$req->subTotal,
            'pay_amount'=>$req->payAmount,
            'pay_left'=>$payleft<0?0:$payleft,
            'change'=>$change<0?0:$change,
            'tax_id'=>$req->taxId,
            'tax_price'=>$req->taxPrice,
            'profit'=>$profit,
            'currency'=>$req->currency,
            'shop_id'=>$req->shop_id,
            'shop_name'=>$req->shop_name,
            'seller_name'=>Auth::user()->name,
            'status'=>$payleft<=0?1:0,
        ];
        $order=Order::create($orderData);
        foreach($cart as $item){
            $storeItem=StoreItem::select('store_items.*','categories.name as cateogry_name')
                            ->leftJoin('products','store_items.product_id','products.id')
                            ->leftJoin('categories','products.category_id','categories.id')
                            ->where('id',$item->store_item_id)
                            ->first();
            $temp=[
                'order_id'=>$order->id,
                'store_product_id'=>$item->store_item_id,
                'product_name'=>$item->product_name,
                'category_name'=>$storeItem->category_name,
                'qty'=>$item->qty,
                'price'=>$item->price,
                'profit'=>$storeItem->profit,
                'currency'=>$storeItem->currency,
                'note'=>$item->note,
            ];
            $orderItem=OrderItem::create($temp);
        }

    }

}
