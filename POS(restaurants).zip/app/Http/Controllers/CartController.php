<?php

namespace App\Http\Controllers;

use App\Models\Tax;
use App\Models\Cart;
use App\Models\Store;
use App\Models\Payment;
use App\Models\Category;
use App\Models\Promotion;
use App\Models\StoreItem;
use App\Models\WebsiteInfo;
use Illuminate\Http\Request;
use App\Events\StockChangeEvent;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function addCart($id){

        $userId = auth()->id();

        $storeItem = StoreItem::select('store_items.*', 'stores.shop_id')
            ->leftJoin('stores', 'store_items.store_id', 'stores.id')
            ->where('store_items.id', $id)
            ->firstOrFail();

        $currentItem = Cart::where('user_id', $userId)
            ->where('store_item_id', $id)
            ->first();

        if ($currentItem) {
            return back()->with(['warning' => 'Product is already in cart.']);
        }

        // Check stock
        if ($storeItem->instock_type != 1 && $storeItem->qty <= 0) {
            return back()->with(['warning' => 'Product instock is not enough.']);
        }

        $cartProducts = Cart::select('carts.*', 'stores.shop_id')
            ->leftJoin('store_items', 'carts.store_item_id', 'store_items.id')
            ->leftJoin('stores', 'store_items.store_id', 'stores.id')
            ->where('user_id', $userId)
            ->get();

        if ($cartProducts->isNotEmpty()) {

            $firstCart = $cartProducts->first();

            if ($firstCart->shop_id != $storeItem->shop_id) {
                return back()->with(['warning' => "You can't choose product from another shop."]);
            }

            if ($firstCart->currency != $storeItem->currency) {
                return back()->with(['warning' => "You can't choose product with another currency."]);
            }
        }

        DB::transaction(function () use ($storeItem, $userId) {
            $data = $this->changeFormat($storeItem);
            $data['user_id'] = $userId;

            Cart::create($data);

            if ($storeItem->instock_type != 1) {
                $storeItem->decrement('qty', 1);
            }
        });
        if ($storeItem->instock_type!=1) {
            $this->stockChangeEvent($storeItem->id,$storeItem->qty);
        }
        return back()->with(['success' => 'Add to cart successful.']);
    }

    public function addCartBarcode(Request $req){
        $userId = auth()->id();
        $scannedId = $req->id;
        $storeItem = StoreItem::select('store_items.*', 'stores.shop_id')
            ->leftJoin('stores', 'store_items.store_id', 'stores.id')
            ->where('store_items.barcode',$scannedId)
            ->firstOrFail();

        $currentItem = Cart::where('user_id', $userId)
            ->where('store_item_id', $storeItem->id)
            ->first();

        if ($currentItem) {
            return back()->with(['warning' => 'Product is already in cart.']);
        }

        // Check stock
        if ($storeItem->instock_type != 1 && $storeItem->qty <= 0) {
            return back()->with(['warning' => 'Product instock is not enough.']);
        }

        $cartProducts = Cart::select('carts.*', 'stores.shop_id')
            ->leftJoin('store_items', 'carts.store_item_id', 'store_items.id')
            ->leftJoin('stores', 'store_items.store_id', 'stores.id')
            ->where('user_id', $userId)
            ->get();

        if ($cartProducts->isNotEmpty()) {

            $firstCart = $cartProducts->first();

            if ($firstCart->shop_id != $storeItem->shop_id) {
                return back()->with(['warning' => "You can't choose product from another shop."]);
            }

            if ($firstCart->currency != $storeItem->currency) {
                return back()->with(['warning' => "You can't choose product with another currency."]);
            }
        }

        DB::transaction(function () use ($storeItem, $userId) {
            $data = $this->changeFormat($storeItem);
            $data['user_id'] = $userId;

            Cart::create($data);

            if ($storeItem->instock_type != 1) {
                $storeItem->decrement('qty', 1);
            }
        });
        if ($storeItem->instock_type!=1) {
            $this->stockChangeEvent($storeItem->id,$storeItem->qty);
        }
        return back()->with(['success' => 'Add to cart successful.']);

    }

    public function removeCart($id){
        $cart=Cart::findOrFail($id);
        $storeItem=StoreItem::findOrFail($cart->store_item_id);
        if ($storeItem->instock_type==0) {
            $storeItem->increment('qty',$cart->qty);
            $this->stockChangeEvent($storeItem->id,$storeItem->qty);
        }
        $cart->delete();
        return back();
    }

    public function removeCartAll(){
        $cart=Cart::where('user_id',Auth::user()->id)->get();
        foreach ($cart as $item) {
            $storeItem=StoreItem::findOrFail($item->store_item_id);
            if ($storeItem->instock_type==0) {
                $storeItem->increment('qty',$item->qty);
                $this->stockChangeEvent($storeItem->id,$storeItem->qty);
            }
        }
        Cart::where('user_id',Auth::user()->id)->delete();
        return back();
    }

    public function cartList(){
        $product=StoreItem::select('store_items.*','products.name as product_name','products.image as product_image')
                        ->leftJoin('products','store_items.product_id','products.id')
                        ->leftJoin('categories','products.category_id','categories.id')
                        ->leftJoin('stores','store_items.store_id','stores.id')
                        ->when(Auth::user()->shop!=null,function($query){
                            $query->where('stores.shop_id',Auth::user()->shop);
                        })
                        ->where('store_items.active',1)
                        ->where('store_items.type',0)
                        ->where('store_items.qty','>',0)
                        ->when(request('category'),function($query){
                            $query->where('categories.name',request('category'));
                        })->when(request('search_key'),function($query){
                            $query->where('products.name','like','%'.request('search_key').'%');
                        })->get();
        $category=Category::get();
        $cartProduct=Cart::select('carts.*','store_items.selling_price','products.name as product_name',
                            'store_items.qty as instock','store_items.instock_type')
                            ->leftJoin('store_items','carts.store_item_id','store_items.id')
                            ->leftJoin('products','store_items.product_id','products.id')
                            ->where('user_id',Auth::user()->id)->get();

        $websiteInfo=WebsiteInfo::where('id',1)->first();
        if ($websiteInfo->multi_cart) {
            return view('main.admin.cart.index',compact('product','category','cartProduct'));
        }else{
            return view('main.admin.cart.single_cart',compact('product','category','cartProduct'));
        }
    }

    public function getCartData(){
        $cartProduct=Cart::where('user_id',Auth::user()->id)->get();
        logger('test');
        return response()->json($cartProduct, 200);
    }

    public function cartChangeQty(Request $req){
        $cart=Cart::findOrFail($req->id);
        $storeItem=StoreItem::findOrFail($cart->store_item_id);
        DB::beginTransaction();
        if ($req->status=='plus') {
            if ($storeItem->qty>$cart->qty || $storeItem->instock_type==1) {
                $cart->qty++;
                if ($storeItem->instock_type!=1) {
                    $storeItem->qty--;
                }
            }
        }else{
            if ($cart->qty>1) {
                $cart->qty--;
                if ($storeItem->instock_type!=1) {
                    $storeItem->qty++;
                }
            }
        }
        $storeItem->save();
        $cart->save();
        DB::commit();
        if ($storeItem->instock_type!=1) {
            $this->stockChangeEvent($storeItem->id,$storeItem->qty);
        }
        return response()->json(['status'=>'success','qty'=>$cart->qty,'price'=>$cart->price*$cart->qty], 200);
    }

    public function updateNote(Request $req){
        Cart::where('id',$req->id)->update(['note'=>$req->note]);
        return back();
    }

    public function getStoreItem(){
        logger(request('category'));
        logger('get');
        $product=StoreItem::select('store_items.*','products.name as product_name','products.image as product_image')
                ->leftJoin('products','store_items.product_id','products.id')
                ->leftJoin('categories','products.category_id','categories.id')
                ->leftJoin('stores','store_items.store_id','stores.id')
                ->when(Auth::user()->shop!=null,function($query){
                    $query->where('stores.shop_id',Auth::user()->shop);
                })
                ->where('store_items.active',1)
                ->where('store_items.type',0)
                ->where('store_items.qty','>',0)
                ->when(request('category'),function($query){
                    $query->where('categories.name',request('category'));
                })->when(request('search_key'),function($query){
                    $query->where('products.name','like','%'.request('search_key').'%');
                })->get();
        return response()->json($product, 200);
    }

    public function createCart(Request $req){
        $promotion=Promotion::where('active',1)->get();
        $tax=Tax::where('active',1)->get();
        $payment=Payment::where('active',1)->when(Auth::user()->shop_id,function($query){
                    $query->where('shop_id',Auth::user()->shop);
                })->orWhere('shop_id',null)->get();
        $cartProduct=json_decode($req->cart);
        $storeId=$cartProduct[0]->store_id;
        $shop=Store::select('shops.*')
                    ->where('stores.id',$storeId)
                    ->leftJoin('shops','stores.shop_id','shops.id')
                    ->first();
        return view('main.admin.cart.checkout',compact('cartProduct','promotion','tax','payment','shop'));
    }

    public function checkOut(){
        $promotion=Promotion::where('active',1)->get();
        $tax=Tax::where('active',1)->get();
        $payment=Payment::where('active',1)->when(Auth::user()->shop_id,function($query){
                    $query->where('shop_id',Auth::user()->shop);
                })->orWhere('shop_id',null)->get();
        $cartProduct=Cart::select('carts.*','store_items.selling_price','products.name as product_name','store_items.qty as instock','store_items.store_id')
                        ->leftJoin('store_items','carts.store_item_id','store_items.id')
                        ->leftJoin('products','store_items.product_id','products.id')
                        ->where('user_id',Auth::user()->id)->get();
        $storeId=$cartProduct[0]->store_id;
        $shop=Store::select('shops.*')
                    ->where('stores.id',$storeId)
                    ->leftJoin('shops','stores.shop_id','shops.id')
                    ->first();
        return view('main.admin.cart.checkout',compact('cartProduct','promotion','tax','payment','shop'));
    }

    // private function
    private function changeFormat($storeItem){
        return [
            'user_id'=>Auth::user()->id,
            'store_item_id'=>$storeItem->id,
            'qty'=>1,
            'price'=>$storeItem->selling_price,
            'currency'=>$storeItem->currency,
        ];
    }

    private function stockChangeEvent($id,$qty){
        event(new StockChangeEvent($id,$qty));
    }

}
